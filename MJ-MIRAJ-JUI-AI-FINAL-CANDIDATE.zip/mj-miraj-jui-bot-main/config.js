/* Public endpoints only. Set these to your deployed HTTPS API host.
 * Never put API keys/secrets in this file: it runs in the browser.
 */
window.MJ_MIRAJ_CONFIG = {
  marketDataUrl: 'https://YOUR-API-HOST.example/api/market/analyze',
  visionUrl: 'https://YOUR-API-HOST.example/api/vision/analyze'
};
