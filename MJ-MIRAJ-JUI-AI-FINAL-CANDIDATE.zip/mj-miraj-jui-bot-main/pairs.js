/* Single source of truth for the allowed pair list and labels. */
window.MJMirajPairs = Object.freeze({
  REAL: Object.freeze(['EUR/JPY','USD/JPY','GBP/JPY','EUR/USD','GBP/USD']),
  OTC: Object.freeze(['USD/NGN (OTC)','GBP/NZD (OTC)','USD/ARS (OTC)','USD/DZD (OTC)','USD/INR (OTC)','USD/BRL (OTC)','USD/BDT (OTC)','USD/COP (OTC)','USD/MXN (OTC)','USD/PKR (OTC)']),
  classify(pair) {
    if (this.REAL.includes(pair)) return 'REAL';
    if (this.OTC.includes(pair)) return 'OTC';
    return null;
  }
});
