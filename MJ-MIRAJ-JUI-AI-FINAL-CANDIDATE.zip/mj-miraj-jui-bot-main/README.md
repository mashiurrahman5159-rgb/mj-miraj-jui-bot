# MJ MIRAJ JUI AI — Mobile Bookmark Overlay + API

This project is designed as a mobile-first overlay loaded over the Quotex page by a Chrome bookmarklet. It does not place trades.

## Included
- Original project assets and UI files preserved.
- Exactly 15 supported display labels: 5 REAL and 10 OTC; USD/DZD is OTC.
- Four member sections: LIVE MARKET ANALYSIS, SCREENSHOT ANALYSIS, FUTURE SIGNAL ANALYSIS, 1–6 STEP COMPOUNDING.
- Server-side Twelve Data adapter for the five REAL currency pairs.
- Server-side OpenAI Vision adapter that receives the actual uploaded screenshot.
- Missing service/data fails closed with the specified unavailable messages; no sample prices/signals.
- Screenshot values are shown as estimates; uncertain values remain blank/null.
- 1–6 step non-Martingale calculator.
- English setup guide, environment template, bookmarklet text, and test report.

## Critical limits
- API keys were not supplied in this chat. The upstream services have NOT been authenticated or live-tested.
- Normal FX providers do not provide Quotex synthetic OTC candles. This build intentionally returns `LIVE DATA NOT CONNECTED` for OTC until a genuine authorized feed for those exact OTC instruments is configured.
- Fundamental/news analysis and a real 5-second tick stream are not included/configured.
- Auto-pair detection reads visible Quotex page text and is best-effort; mobile browser/CSP changes may block it. Always verify the selected pair.
- A bookmarklet cannot guarantee access to page internals or bypass browser security rules.
- For privacy, do not publish internal strategy source in a public repository. The backend strategy file must be kept in a private repository/deployment. A public ZIP necessarily exposes any source code included in it.
- Production-grade server-side license/device activation is not implemented in this API package.

## Configure backend
See `DEPLOY_EN.md`. Keep `.env` private. Do not put provider keys into `config.js` or bookmarklet code.
