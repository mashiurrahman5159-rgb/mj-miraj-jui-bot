'use strict';
require('dotenv').config();
const express = require('express');
const multer = require('multer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const app = express();
require('./signal-logic.js');
const signalLogic = globalThis.MJMirajSignalLogic;
const PORT = Number(process.env.PORT || 8787);
const ALLOWED_PAIRS = {
  REAL: ['EUR/JPY','USD/JPY','GBP/JPY','EUR/USD','GBP/USD'],
  OTC: ['USD/NGN (OTC)','GBP/NZD (OTC)','USD/ARS (OTC)','USD/DZD (OTC)','USD/INR (OTC)','USD/BRL (OTC)','USD/BDT (OTC)','USD/COP (OTC)','USD/MXN (OTC)','USD/PKR (OTC)']
};
const classify = p => ALLOWED_PAIRS.REAL.includes(p) ? 'REAL' : ALLOWED_PAIRS.OTC.includes(p) ? 'OTC' : null;
const origins = (process.env.ALLOWED_ORIGINS || 'https://market-qx.info,https://quotex.com').split(',').map(x=>x.trim()).filter(Boolean);
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' }, contentSecurityPolicy: false }));
app.use((req,res,next)=>{
  const origin=req.headers.origin;
  if(origin && (origins.includes(origin) || origins.includes('*'))) {
    res.setHeader('Access-Control-Allow-Origin', origins.includes('*') ? '*' : origin);
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization');
  }
  if(req.method==='OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json({limit:'32kb'}));
app.use(rateLimit({windowMs:60_000,limit:30,standardHeaders:true,legacyHeaders:false}));
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:8*1024*1024,files:1},fileFilter:(req,file,cb)=>cb(null,['image/png','image/jpeg','image/webp'].includes(file.mimetype))});
app.get('/health',(req,res)=>res.json({ok:true,service:'MJ MIRAJ JUI AI API',marketConfigured:Boolean(process.env.TWELVE_DATA_API_KEY),visionConfigured:Boolean(process.env.OPENAI_API_KEY),otcFeedConfigured:false}));
app.post('/api/market/analyze', async (req,res)=>{
  try {
    const {pair,timeframe='1m',limit=100}=req.body||{};
    const type=classify(pair);
    if(!type) return res.status(400).json({error:'UNSUPPORTED_PAIR',signal:'WAIT'});
    // OTC prices on Quotex may be broker-generated/synthetic. Never substitute normal FX data.
    if(type==='OTC') return res.status(503).json({error:'OTC_FEED_NOT_CONFIGURED',message:'LIVE DATA NOT CONNECTED',signal:'WAIT'});
    if(timeframe!=='1m') return res.status(400).json({error:'UNSUPPORTED_TIMEFRAME'});
    if(!process.env.TWELVE_DATA_API_KEY) return res.status(503).json({error:'MARKET_API_NOT_CONFIGURED',message:'LIVE DATA NOT CONNECTED',signal:'WAIT'});
    const symbol=pair.replace('/','/');
    const url=new URL('https://api.twelvedata.com/time_series');
    url.searchParams.set('symbol',symbol);url.searchParams.set('interval','1min');url.searchParams.set('outputsize',String(Math.min(100,Math.max(30,Number(limit)||100))));url.searchParams.set('apikey',process.env.TWELVE_DATA_API_KEY);url.searchParams.set('format','JSON');url.searchParams.set('timezone','UTC');
    const upstream=await fetch(url,{signal:AbortSignal.timeout(12_000)});
    if(!upstream.ok) throw new Error('MARKET_PROVIDER_HTTP_'+upstream.status);
    const json=await upstream.json();
    if(json.status==='error'||!Array.isArray(json.values)) return res.status(503).json({error:'MARKET_PROVIDER_NO_DATA',message:'LIVE DATA NOT CONNECTED',signal:'WAIT'});
    const candles=json.values.map(v=>({time:new Date(String(v.datetime).replace(' ','T')+'Z').toISOString(),open:Number(v.open),high:Number(v.high),low:Number(v.low),close:Number(v.close)})).filter(c=>[c.open,c.high,c.low,c.close].every(Number.isFinite)).reverse();
    if(candles.length<30) return res.status(503).json({error:'INSUFFICIENT_FRESH_CANDLES',message:'LIVE DATA NOT CONNECTED',signal:'WAIT'});
    const last=candles[candles.length-1], lastUpdated=last.time;
    if(!Number.isFinite(Date.parse(lastUpdated)) || Date.now()-Date.parse(lastUpdated)>180_000) return res.status(503).json({error:'STALE_MARKET_DATA',message:'LIVE DATA NOT CONNECTED',signal:'WAIT'});
    if(!signalLogic || typeof signalLogic.analyze!=='function') return res.status(503).json({error:'ANALYSIS_ENGINE_UNAVAILABLE',message:'LIVE DATA NOT CONNECTED',signal:'WAIT'});
    const analysis=signalLogic.analyze(candles,pair,{minimumConfirmations:6});
    // Timing is derived from the provider's latest candle timestamp, not a fixed wall-clock time.
    // Only publish a candidate entry window for a non-WAIT setup; the next candle may still change.
    let entryTime=null,tradeTime=null,candleCloseTime=null,expiryTime=null;
    if(analysis.signal!=='WAIT') {
      const nextOpen=new Date(Date.parse(lastUpdated)+60_000);
      const nextClose=new Date(nextOpen.getTime()+60_000);
      if(Number.isFinite(nextOpen.getTime()) && nextOpen.getTime()>Date.now()-15_000) {
        entryTime=nextOpen.toISOString();tradeTime=entryTime;candleCloseTime=nextClose.toISOString();expiryTime=candleCloseTime;
      } else { analysis.signal='WAIT'; analysis.note='WAIT: provider candle timing is stale or unsuitable for a verified entry window.'; }
    }
    return res.json({...analysis,pair,marketType:type,timeframe:'1m',candles,lastUpdated,provider:'Twelve Data',entryTime,tradeTime,candleCloseTime,expiryTime,analysisTime:new Date().toISOString(),note:analysis.note||'Technical analysis only; no outcome is guaranteed.'});
  } catch(err) {
    console.error('market endpoint:',err.message);
    return res.status(503).json({error:'MARKET_PROVIDER_UNAVAILABLE',message:'LIVE DATA NOT CONNECTED',signal:'WAIT'});
  }
});
app.post('/api/vision/analyze', upload.single('image'), async (req,res)=>{
  try {
    if(!req.file) return res.status(400).json({error:'NO_IMAGE',message:'PLEASE UPLOAD A QUOTEX CHART SCREENSHOT',signal:'WAIT'});
    const {pair,timeframe='1m'}=req.body||{};const type=classify(pair);
    if(!type) return res.status(400).json({error:'UNSUPPORTED_PAIR',signal:'WAIT'});
    if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'VISION_API_NOT_CONFIGURED',message:'IMAGE ANALYSIS SERVICE NOT CONNECTED',signal:'WAIT'});
    const dataUrl=`data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    const prompt=`Analyze only the actual uploaded trading chart screenshot. Pair selected by user: ${pair} (${type}). Timeframe requested: ${timeframe}. Do not claim access to hidden/live data. Return JSON only with keys: signal (UP/DOWN/WAIT), pair, marketType, timeframe, reason, trend, momentum, movementStrength, candle (open,close,high,low,body,upperWick,lowerWick), levels (support,resistance), insufficient (boolean). Any numeric candle/OHLC values must be estimated ONLY if visibly inferable from chart axis/candles; otherwise use null. Do not invent prices, timestamps, expiry or entry times. If chart is cropped, unreadable, or insufficient, signal WAIT, insufficient true, and explain. Signal should be UP only when visible trend and candle structure support UP; DOWN only when they support DOWN; otherwise WAIT. Do not give confidence/accuracy guarantees. Return valid JSON without markdown.`;
    const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_VISION_MODEL||'gpt-4o-mini',temperature:0,max_tokens:700,response_format:{type:'json_object'},messages:[{role:'user',content:[{type:'text',text:prompt},{type:'image_url',image_url:{url:dataUrl,detail:'high'}}]}]}),signal:AbortSignal.timeout(45_000)});
    if(!response.ok){console.error('vision provider HTTP',response.status);return res.status(503).json({error:'VISION_PROVIDER_UNAVAILABLE',message:'IMAGE ANALYSIS SERVICE NOT CONNECTED',signal:'WAIT'});}
    const payload=await response.json();const content=payload.choices?.[0]?.message?.content;
    if(!content) return res.status(503).json({error:'EMPTY_VISION_RESPONSE',message:'IMAGE ANALYSIS SERVICE NOT CONNECTED',signal:'WAIT'});
    let result;try{result=JSON.parse(content);}catch(_){return res.status(503).json({error:'INVALID_VISION_RESPONSE',message:'IMAGE ANALYSIS SERVICE NOT CONNECTED',signal:'WAIT'});}
    if(!['UP','DOWN','WAIT'].includes(result.signal)) result.signal='WAIT';
    result.pair=pair;result.marketType=type;result.timeframe='1 minute';result.analysisTime=new Date().toISOString();
    if(result.insufficient===true){result.signal='WAIT';result.reason='INSUFFICIENT CHART INFORMATION — WAIT';}
    // Never infer times or prices not returned from visible chart data.
    result.entryTime=null;result.tradeTime=null;result.candleCloseTime=null;result.expiryTime=null;
    return res.json(result);
  } catch(err) {
    console.error('vision endpoint:',err.message);
    return res.status(503).json({error:'VISION_PROVIDER_UNAVAILABLE',message:'IMAGE ANALYSIS SERVICE NOT CONNECTED',signal:'WAIT'});
  }
});
app.use((err,req,res,next)=>{if(err instanceof multer.MulterError)return res.status(400).json({error:'UPLOAD_REJECTED',message:'Image must be PNG, JPG, or WEBP and under 8 MB.'});console.error('server error:',err.message);res.status(500).json({error:'INTERNAL_ERROR'});});
app.listen(PORT,()=>console.log(`MJ MIRAJ JUI AI API listening on ${PORT}`));
