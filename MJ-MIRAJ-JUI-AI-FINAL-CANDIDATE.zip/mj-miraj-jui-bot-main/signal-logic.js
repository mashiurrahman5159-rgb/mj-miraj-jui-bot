/* MJ MIRAJ JUI AI — conservative OHLC analysis engine.
 * Only analyzes genuine candles supplied by a trusted backend. It never fetches or invents data.
 * Fundamental news and 5-second tick confirmation require separate authorized services/streams.
 */
(function (root) {
  'use strict';
  const PAIRS = {
    REAL: ['EUR/JPY','USD/JPY','GBP/JPY','EUR/USD','GBP/USD'],
    OTC: ['USD/NGN (OTC)','GBP/NZD (OTC)','USD/ARS (OTC)','USD/DZD (OTC)','USD/INR (OTC)','USD/BRL (OTC)','USD/BDT (OTC)','USD/COP (OTC)','USD/MXN (OTC)','USD/PKR (OTC)']
  };
  function classifyPair(pair) { return PAIRS.REAL.includes(pair) ? 'REAL' : PAIRS.OTC.includes(pair) ? 'OTC' : null; }
  const num = v => typeof v === 'number' ? v : Number(v);
  function valid(c) { return c && [c.open,c.high,c.low,c.close].every(v=>Number.isFinite(num(v))) && num(c.high)>=Math.max(num(c.open),num(c.close)) && num(c.low)<=Math.min(num(c.open),num(c.close)) && num(c.high)>=num(c.low); }
  function cv(c) { const o=num(c.open),h=num(c.high),l=num(c.low),cl=num(c.close),range=h-l,body=Math.abs(cl-o); return {open:o,high:h,low:l,close:cl,body,upperWick:h-Math.max(o,cl),lowerWick:Math.min(o,cl)-l,range,bull:cl>o,bear:cl<o,doji:range>0&&body/range<=.1,mid:(h+l)/2}; }
  const avg=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:NaN;
  function ema(a,p){if(a.length<p)return NaN;const k=2/(p+1);let v=avg(a.slice(0,p));for(let i=p;i<a.length;i++)v=a[i]*k+v*(1-k);return v;}
  function rsi(a,p=14){if(a.length<p+1)return NaN;let g=0,l=0;for(let i=a.length-p;i<a.length;i++){const d=a[i]-a[i-1];if(d>0)g+=d;else l-=d;}return l===0?100:100-100/(1+g/l);}
  function analyze(candles,pair,opts={}) {
    const type=classifyPair(pair);
    if(!type)return {signal:'WAIT',reason:'UNSUPPORTED PAIR',pair,marketType:null};
    if(!Array.isArray(candles)||candles.length<30||!candles.every(valid))return {signal:'WAIT',reason:'LIVE DATA NOT CONNECTED OR INSUFFICIENT VALID CANDLES',pair,marketType:type};
    const c=candles.map(cv),cl=c.map(x=>x.close),last=c.at(-1),prev=c.at(-2),p3=c.at(-3),recent=c.slice(-10),prior=c.slice(-21,-1);
    const e9=ema(cl,9),e21=ema(cl,21),e50=ema(cl,50),rv=rsi(cl),ranges=c.slice(-14).map(x=>x.range),atr=avg(ranges);
    const trend=e9>e21&&e21>=e50?'UPTREND':e9<e21&&e21<=e50?'DOWNTREND':'SIDEWAYS';
    const hi=Math.max(...prior.map(x=>x.high)),lo=Math.min(...prior.map(x=>x.low)),mid=(hi+lo)/2;
    const recentHi=Math.max(...recent.map(x=>x.high)),recentLo=Math.min(...recent.map(x=>x.low));
    const bullEngulf=last.bull&&prev.bear&&last.open<=prev.close&&last.close>=prev.open;
    const bearEngulf=last.bear&&prev.bull&&last.open>=prev.close&&last.close<=prev.open;
    const morningStar=p3.bear&&prev.body<p3.body*.45&&last.bull&&last.close>(p3.open+p3.close)/2;
    const eveningStar=p3.bull&&prev.body<p3.body*.45&&last.bear&&last.close<(p3.open+p3.close)/2;
    const inside=last.high<prev.high&&last.low>prev.low, outside=last.high>prev.high&&last.low<prev.low;
    const gapUp=last.low>prev.high,gapDown=last.high<prev.low;
    const sweepHigh=last.high>hi&&last.close<hi,sweepLow=last.low<lo&&last.close>lo;
    const fakeBreakUp=sweepHigh|| (last.high>prev.high&&last.close<prev.high),fakeBreakDown=sweepLow||(last.low<prev.low&&last.close>prev.low);
    const wickRejectUp=last.upperWick>Math.max(last.body,atr*.05)*2&&last.upperWick>last.range*.35;
    const wickRejectDown=last.lowerWick>Math.max(last.body,atr*.05)*2&&last.lowerWick>last.range*.35;
    const nearSupport=Math.abs(last.close-recentLo)<=atr*.25,nearResistance=Math.abs(recentHi-last.close)<=atr*.25;
    const colorSense=recent.slice(-3).every(x=>x.bull)?'UP':recent.slice(-3).every(x=>x.bear)?'DOWN':'MIXED';
    const overlap=last.low<=prev.high&&last.high>=prev.low;
    const wickShiftUp=last.lowerWick>prev.lowerWick*1.5&&last.bull,wickShiftDown=last.upperWick>prev.upperWick*1.5&&last.bear;
    const wickZoneUp=last.close-last.low<=atr*.2,wickZoneDown=last.high-last.close<=atr*.2;
    const mPattern=c.length>=5&&c.at(-5).high<c.at(-3).high&&last.high<c.at(-3).high&&Math.abs(c.at(-5).high-last.high)<=atr*.35;
    const wPattern=c.length>=5&&c.at(-5).low>c.at(-3).low&&last.low>c.at(-3).low&&Math.abs(c.at(-5).low-last.low)<=atr*.35;
    const leftShoulder=c.at(-7),head=c.at(-5),rightShoulder=c.at(-3);
    const headShoulders=!!leftShoulder&&head.high>leftShoulder.high&&head.high>rightShoulder.high&&Math.abs(leftShoulder.high-rightShoulder.high)<=atr*.5;
    const roundStep=Math.pow(10,Math.floor(Math.log10(Math.abs(last.close)||1))-1),roundNumber=Math.round(last.close/roundStep)*roundStep;
    const nearRound=Math.abs(last.close-roundNumber)<=roundStep*.08;
    const bosUp=last.close>hi,bosDown=last.close<lo;
    const chochUp=trend==='DOWNTREND'&&last.close>Math.max(...c.slice(-5,-1).map(x=>x.high));
    const chochDown=trend==='UPTREND'&&last.close<Math.min(...c.slice(-5,-1).map(x=>x.low));
    const impulse=last.body>avg(recent.slice(0,-1).map(x=>x.body))*1.5;
    const bullishOB=prev.bear&&last.bull&&last.close>prev.high,bearishOB=prev.bull&&last.bear&&last.close<prev.low;
    const fvgUp=c.length>=3&&c.at(-1).low>c.at(-3).high,fvgDown=c.length>=3&&c.at(-1).high<c.at(-3).low;
    const momentum=last.close>prev.close&&prev.close>p3.close?'UP':last.close<prev.close&&prev.close<p3.close?'DOWN':'MIXED';
    const overlapCluster=recent.slice(-4).filter(x=>x.low<=prev.high&&x.high>=prev.low).length>=3;
    const doji=last.doji;
    let up=0,down=0;const reasons=[];const vote=(u,d,label)=>{if(u){up++;reasons.push('UP: '+label);}else if(d){down++;reasons.push('DOWN: '+label);}};
    vote(trend==='UPTREND',trend==='DOWNTREND','trend / EMA alignment');
    vote(rv>=52&&rv<75,rv<=48&&rv>25,'RSI momentum');
    vote(last.bull&&impulse,last.bear&&impulse,'impulsive pressure candle');
    vote(bullEngulf||morningStar||wPattern,bearEngulf||eveningStar||mPattern||headShoulders,'engulfing / star / M-W / head-and-shoulders pattern');
    vote(sweepLow||fakeBreakDown||wickRejectDown,sweepHigh||fakeBreakUp||wickRejectUp,'liquidity sweep / fake breakout / wick rejection');
    vote(nearSupport||wickShiftUp||wickZoneUp,nearResistance||wickShiftDown||wickZoneDown,'support-resistance / wick zone');
    vote(bosUp||chochUp,bosDown||chochDown,'BOS / CHoCH');
    vote(colorSense==='UP'&&momentum==='UP',colorSense==='DOWN'&&momentum==='DOWN','color sense / momentum');
    vote(bullishOB||fvgUp,bearishOB||fvgDown,'order block / fair value gap');
    const required=Number.isInteger(opts.minimumConfirmations)?Math.max(1,opts.minimumConfirmations):6;
    const conflict=Math.abs(up-down)<2,ambiguous=doji||inside||overlapCluster||trend==='SIDEWAYS'||(!gapUp&&!gapDown&&last.range>0&&last.body/last.range<.12);
    let signal='WAIT';
    // Trend-following gate: UP only in uptrend, DOWN only in downtrend. Conflicts stay WAIT.
    if(!ambiguous&&!conflict&&up>=required&&up>down&&trend==='UPTREND')signal='UP';
    else if(!ambiguous&&!conflict&&down>=required&&down>up&&trend==='DOWNTREND')signal='DOWN';
    const fmt=v=>Number.isFinite(v)?Number(v.toPrecision(10)):null;
    const patternFlags={bullishEngulfing:bullEngulf,bearishEngulfing:bearEngulf,morningStar,eveningStar,doji,insideBar:inside,outsideBar:outside,gapUp,gapDown,fakeBreakoutUp:fakeBreakUp,fakeBreakoutDown:fakeBreakDown,wickShiftingUp:wickShiftUp,wickShiftingDown:wickShiftDown,wickZoneUpper:wickZoneDown,wickZoneLower:wickZoneUp,mPattern,wPattern,headAndShoulders:headShoulders,liquiditySweepHigh:sweepHigh,liquiditySweepLow:sweepLow,overlap,nearRoundNumber:nearRound,bosUp,bosDown,chochUp,chochDown,impulsiveMove:impulse,orderBlockBullish:bullishOB,orderBlockBearish:bearishOB,fvgUp,fvgDown};
    return {signal,pair,marketType:type,timeframe:'1 minute',trend,momentum,confirmations:{up,down,required},indicators:{ema9:fmt(e9),ema21:fmt(e21),ema50:fmt(e50),rsi14:fmt(rv),atr14:fmt(atr)},levels:{support:fmt(recentLo),resistance:fmt(recentHi),fiftyPercent:fmt(mid),roundNumber:fmt(roundNumber),onCandleMidpoint:fmt(last.mid),liquidityHigh:fmt(hi),liquidityLow:fmt(lo)},candle:{open:fmt(last.open),close:fmt(last.close),high:fmt(last.high),low:fmt(last.low),body:fmt(last.body),upperWick:fmt(last.upperWick),lowerWick:fmt(last.lowerWick),color:last.bull?'GREEN':last.bear?'RED':'DOJI'},patterns:patternFlags,reasons,additionalChecks:{snr:'support/resistance levels computed from recent candles',priceAction:'derived from OHLC structure',candlestickAnalysis:'computed',fundamentalAnalysis:'NOT CONNECTED — no news/fundamental feed supplied',fiveSecondConfirmation:'NOT AVAILABLE — requires authorized live tick stream',overlapLevel:overlap,trendEntryRule:'UP only in uptrend; DOWN only in downtrend; otherwise WAIT'},analysisTime:new Date().toISOString(),note:signal==='WAIT'?'No sufficiently aligned setup; wait for confirmation.':'Technical setup only. No outcome or accuracy is guaranteed.'};
  }
  root.MJMirajSignalLogic={PAIRS,classifyPair,analyze};
})(typeof window!=='undefined'?window:globalThis);
