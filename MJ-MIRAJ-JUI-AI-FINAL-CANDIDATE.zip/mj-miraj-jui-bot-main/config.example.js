/* Copy to config.js and set your own HTTPS backend endpoints.
 * Never put API secrets in this browser file. Keep keys on the backend server.
 */
window.MJ_MIRAJ_CONFIG = {
  marketDataUrl: '', // Example: https://YOUR-DOMAIN.example/api/market/analyze
  visionUrl: ''      // Example: https://YOUR-DOMAIN.example/api/vision/analyze
};
