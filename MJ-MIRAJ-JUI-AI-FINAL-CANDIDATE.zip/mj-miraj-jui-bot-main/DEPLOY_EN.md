# MJ MIRAJ JUI AI — API Setup (English)

## Important status
This project now contains server-side adapters for a real Twelve Data 1-minute feed for the five REAL pairs and an OpenAI vision endpoint for actual uploaded screenshots. It cannot be called live-connected until you add valid provider keys and deploy the API. No API keys were provided in this chat, so external provider calls cannot be authenticated or live-tested here.

## Providers and limitations
- REAL pairs: Twelve Data is queried for the exact selected pair. Provider entitlement and pair support must be confirmed with your account.
- OTC pairs: the API deliberately returns `LIVE DATA NOT CONNECTED`. It does not substitute ordinary FX prices for Quotex OTC prices. To enable OTC, you need an authorized provider that truly supports the exact Quotex OTC instruments.
- Screenshot analysis: the actual uploaded image is forwarded to OpenAI Vision. Add your own API key on the server only.
- Five-second confirmation and fundamental/news analysis are not implemented as live data feeds in this package. Do not treat these as active features.

## Deploy
1. Use a private server/repository for `server.js`, `signal-logic.js`, and `.env`. If the GitHub repository is public, internal strategy code is not secret. Keep strategy and API keys in a private backend.
2. Use Node.js 18.17 or newer.
3. Run `npm install`.
4. Copy `.env.example` to `.env`; set `TWELVE_DATA_API_KEY`, `OPENAI_API_KEY`, and `ALLOWED_ORIGINS`. Never commit `.env`.
5. Run `npm start`.
6. Check `https://YOUR-API-HOST/health`. `marketConfigured` and `visionConfigured` should be true.
7. In `config.js`, set `marketDataUrl` to `https://YOUR-API-HOST/api/market/analyze` and `visionUrl` to `https://YOUR-API-HOST/api/vision/analyze`.
8. Host `config.js` and `panel.js` over HTTPS. Make the bookmarklet load them from the published HTTPS host. Browser CSP/CORS or mobile Chrome may block bookmarklets; verify on your device.

## Smoke tests
- `GET /health`: checks whether server-side keys exist (not whether provider credentials are valid).
- `POST /api/market/analyze` JSON `{"pair":"EUR/USD","timeframe":"1m","limit":100}` should return fresh provider candles if your account supports the pair.
- `POST /api/market/analyze` JSON `{"pair":"USD/DZD (OTC)","timeframe":"1m","limit":100}` should return `LIVE DATA NOT CONNECTED` until a true OTC feed is configured.
- `POST /api/vision/analyze` multipart fields: `image` (PNG/JPG/WEBP), `pair`, `timeframe`. The endpoint forwards the actual uploaded file to the configured vision model.
- Missing or invalid provider configuration must fail closed; no fake signal/prices are generated.

## Privacy and security
- Never place API secrets in `config.js`, bookmarklet code, or browser storage.
- The browser no longer needs to download the signal logic for live analysis; the API runs the strategy server-side. However, if this repository is public, anyone can still read the source files in the repository. Use a private backend repository/hosting source to protect the strategy.
- Add authentication/license enforcement before allowing public users to access the API. This package does not yet provide a production-grade server-side license system.
- The app analyzes only and does not place trades. Signals are not guaranteed.
