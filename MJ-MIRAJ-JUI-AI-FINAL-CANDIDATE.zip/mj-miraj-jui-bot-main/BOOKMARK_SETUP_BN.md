# MJ MIRAJ JUI AI — মোবাইল বুকমার্ক সেটআপ

## এই build-এ যা আছে
- মোবাইল-উপযোগী Quotex overlay UI এবং চারটি নির্দিষ্ট বিভাগ।
- নির্দিষ্ট ১৫টি pair; REAL ৫টি, OTC ১০টি (USD/DZD অবশ্যই OTC)।
- Quotex পেজের দৃশ্যমান DOM থেকে best-effort pair detection; নিশ্চিত না হলে pair অনুমান করে না।
- Screenshot file picker, preview এবং reset।
- ১–৬ ধাপের non-Martingale পরিকল্পনা ক্যালকুলেটর; কোনো trade execute করে না।
- Live market-data/AI service অনুপস্থিত থাকলে স্পষ্ট NOT CONNECTED/WAIT দেখায়; fake signal/price তৈরি করে না।

## গুরুত্বপূর্ণ সীমা
এই ZIP একা real live signals বা screenshot AI চালু করে না। তার জন্য authorized fresh OHLC market-data backend এবং AI vision endpoint configure করতে হবে। Quotex-এর pair DOM সব browser/version-এ পড়া যাবে এমন নিশ্চয়তা নেই; auto-detection ভুল/ambiguous হলে UI-তে manually pair বেছে নিন। এটি auto-trading করে না। Client-side license check secure নয়; production license enforcement-এর জন্য backend দরকার।

## Bookmark ব্যবহার
এই project-এর `panel.js` হলো overlay script। সাধারণ website bookmark শুধু HTML খুলে; Quotex-এর উপর overlay চালাতে script-টি HTTPS-এ host করতে হবে এবং একটি JavaScript bookmarklet থেকে সেই hosted script load করতে হবে। Android Chrome-এ bookmarklet execution সীমিত/বিভিন্ন হতে পারে। Browser security/CSP বাধা দিলে bookmarklet কাজ নাও করতে পারে। এই ZIP-এ কোনো fake hosted URL রাখা হয়নি—deploy করার পর নিজের প্রকৃত HTTPS script URL ব্যবহার করতে হবে।
